/**
 * 
 */
/**
 * @author hp
 *
 */
module HelloWorld2 {
}