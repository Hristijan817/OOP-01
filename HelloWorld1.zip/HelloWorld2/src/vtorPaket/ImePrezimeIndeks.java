package vtorPaket;

public class ImePrezimeIndeks {

	public static void main(String[] args) {
		String firstName = "Hristijan";
		String lastName = "Jankulovski";
		int index = 852;
		
		System.out.println("Zdravo, jas sum " + firstName + " " + lastName + ". Mojot broj na indeks e " + index);
		
	}
}
