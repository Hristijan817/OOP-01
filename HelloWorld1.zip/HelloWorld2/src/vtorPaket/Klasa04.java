package vtorPaket;

public class Klasa04 {

	public static void main(String[] args) {
		double a = 0.2;
		double b = 0.3;
		String name = "Pravoagolnik";
		String value1 = "Ploshtina";
		
		System.out.println(name + "ot ima strani a=" + (int) (a*100)+ "cm i b="+ (int)(b*10) + "cm");
		System.out.println(value1 + "ta iznesuva " + (int) (a*b*1000) + "cm");
		
		
		
		
		
		
	}
	
	
	
}
