package vtorPaket;

public class Klasa06 {

	public static void main(String[] args) {
		String article1 = "cokolado";
		String price1 = "50";
		String quantity = "5";
		String article2 = "sok";
		String price2 = "35";
		String unit = "denari";
		
		int chocolatePrice = Integer.parseInt(price1) * Integer.parseInt(quantity);
		int juicePrice = Integer.parseInt(price2) * Integer.parseInt(quantity);
		int totalPrice = chocolatePrice + juicePrice;
		
		System.out.println("Smetka:");
		System.out.println("Edno " + article1 + "-" + price1 + " " + unit + ".");
		System.out.println(price1 + " x " + quantity + " = " + chocolatePrice);
		
		System.out.println("Eden " + article2 + "-" + price2 + " " + unit + ".");
		System.out.println(price2 + " x " + quantity + " = " + juicePrice);
		System.out.println("Vkupna cena: " + totalPrice); 
		
		
		
		
		
	}
	
	
	
	
}
