package vtorPaket;

public class SecondHelloWorld {

	public static void main(String[] args) {
		String firstString = "Hello";
		String secondString = "World";
		
		System.out.println(firstString + " "+ secondString + "!");
		
		
		
		
		
		
	}
	
	
}
